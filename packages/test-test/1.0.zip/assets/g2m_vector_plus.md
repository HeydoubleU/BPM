# `g2m_hsv_to_rgb`

hex string to rgb

version: 2021-9-2

author: g2mXagent@ya.ru

## example1

### input hex_string
"#FFF"
### output RGB
<1, 1, 1>

## example2

### input hex_string
"808080"
### output RGB
<0.5, 0.5, 0.5>