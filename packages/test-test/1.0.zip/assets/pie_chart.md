# `pie_chart`

版本：6
最后更新：2021-5-7
作者：g2mXagent@ya.ru

程序化餅圖。

## 輸入

### `Export_Strand`

勾選輸出 Strand 參考線。

### `Export_Mesh`

勾選才會輸出模型。

### `piece_value_sequence`

餅塊序列。假設你有十隻羊，十五頭牛，七頭駱駝，二十隻鷄，就鍵入：

> 10, 15, 7, 20

生成四塊餠，比例是 10:15:7:20
什麽都不輸入會有個默認值。

### `start_angle`

開始角度

### `full_moon_angle`

餅圖的角度數。

### `per_90d_sides`

每90度餠的邊數。值越大模型越平滑。一般 12 足以。小於 1 餠消失。

### `inner_radius`

內環半徑。

### `outer_radius`

外環半徑。

### `gap_width`

餅塊間隙寬度。

### `extrude`

擠出高度。

### `angle_factor`

餅塊完整度。值介於 0~1 之間。1 表示完整的餅塊，0 表示沒有餅塊。

### `bisector_offset`

使餅塊在角平分線上移動。

### `y_offset`

餅塊在 Y 軸移動。

### `hsv_color`

手動輸入 HSV 顔色值。HSV 表示色相、飽和度和亮度值。

### `random_hue`

隨機 Hue 值

### `random_seed`

隨即顏色種子，不同的值生成不同的顔色。當前隨機顔色功能不是很好用，總有重複或極接近的顔色。

### `ranbow_hue`

彩虹色。會覆蓋 random_hue 。

### `per_inner_radius_sequence`

### `per_outer_radius_sequence`

### `per_gap_width_sequence`

### `per_extrude_sequence`

### `per_angle_factor_sequence`

### `per_hsv_color_sequence`
手動輸入每塊餠的內徑、外徑、間隙、擠出、角度和顏色值。
類似 piece_value_sequence ，每個值用“逗號”隔開。你不用輸入所有值，系統能自動重複最后一個值。假設你的餅圖有五塊，而你只輸入兩個值：

> 0, 0.2

系統自動補充後的結果是：

> 0, 0.2, 0.2, 0.2, 0.2

對於每塊餠的顔色值。假設第一塊純紅，第二塊純黑，則輸入：

> 0, 1, 1, 0, 0, 0

** per_xxx 輸入的值，優先級高於之前的設定。

### `per_piece_attr_connect`

可以接入餅值的數組

** 優先級最高，能覆蓋同類設定。

## 輸出

### `out_geometry`

餅圖模型

### `out_strands_guide`

strand 參考線。

