# `g2m_rgb_to_hsv`

rgb to hsv

version: 2021-8

author: g2mXagent@ya.ru

## 示例1

### input RGB
<1, 1, 0>
### output HSV
<0.1667, 1, 1>