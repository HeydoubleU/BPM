# `g2m_strand_smooth`

## INPUT

### `strand_in`
strand input.

### `segment`
curve segments. more larger more smoother.

### `length`
curve length. 0~1.