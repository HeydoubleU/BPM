# `g2m_array_shift`

最后更新：2021-11
作者：g2mXagent@ya.ru

## 示例1

### `array`
[0,1,2,3,4]
### `direction`
0
### `shifted`
[0,1,2,3,4]

## 示例2

### `array`
[0,1,2,3,4]
### `direction`
1
### `shifted`
[1,2,3,4,0]

## 示例3

### `array`
[0,1,2,3,4]
### `direction`
-2
### `shifted`
[3,4,0,1,2]

