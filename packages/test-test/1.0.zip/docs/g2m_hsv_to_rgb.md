# `g2m_hsv_to_rgb`

hsv to rgb

version: 2021-8

author: g2mXagent@ya.ru

## example1

### input HSV
<0.1667, 1, 1>
### output RGB
<1, 1, 0>