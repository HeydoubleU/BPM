# `g2m_pie_chart`

版本：7
最后更新：2021-5-10
作者：g2mXagent@ya.ru

程序化餅圖。

## 輸入

### `Export_Strand`

勾選輸出 Strand 參考線。

### `Export_Mesh`

勾選才會輸出模型。

### `start_angle`

開始角度

### `full_moon_angle`

餅圖的角度數。

### `per_90d_sides`

每90度餠的邊數。值越大模型越平滑。一般 12 足以。小於 1 餠消失。

### `piece_value`

餅塊的值。數組中每個值對應一個餅塊。大於 0 的值才有效。
* 僅接受 float 或 float array 數據。其他數據將被忽略，從而使用默認值。（下同）

### `inner_radius`

內環半徑。

### `outer_radius`

外環半徑。

### `gap_width`

餅塊間隙寬度。

### `extrude`

擠出高度。

### `angle_factor`

餅塊完整度。值介於 0~1 之間。1 表示完整的餅塊，0 表示沒有餅塊。

### `invert_angle_factor`

餅塊完整度。值介於 0~1 之間。0 表示完整的餅塊，1 表示沒有餅塊。

### `bisector_offset`

使餅塊在角平分線上移動。

### `y_offset`

餅塊在 Y 軸移動。

### `hsv_color`

手動輸入 HSV 顔色值。HSV 表示色相、飽和度和亮度值。

### `random_hue`

隨機 Hue 值

### `random_seed`

隨即顏色種子，不同的值生成不同的顔色。當前隨機顔色功能不是很好用，總有重複或極接近的顔色。

### `ranbow_hue`

彩虹色。會覆蓋 random_hue 。

## 輸出

### `out_geometry`

餅圖模型

### `out_strands_guide`

strand 參考線。

