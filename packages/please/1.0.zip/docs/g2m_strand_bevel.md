# `g2m_strand_bevel`

## INPUT

### `strand_in`
strand input.

### `is_closed`
if the input curve is closed, turn on this.

### `segments_mode`
選擇倒角分段的計算方法。
1. specify_segments：手動指定拐角的分段數。manually input the actual number of bevel segments. 
2. depend_on_angle：根據拐角的夾角自動計算分段數。the bevel segments depends on the current angle.

### `bevel_segments`
the actual number of bevel segments.
you can input an array to define each bevel or a single value to define all bevels.

### `max_segments` and `min_segments`
max 表示當拐角 0 度時的分段數。min 表示當拐角爲 180 度時的分段數。

### `radius_mode`
how to determine the bevel radius.
1. specify_radius: specify radius directly.
2. specify_distance: specifies the distance between the bevel center and the bevel point.
3. depend_on_angle: the radius depends on the current Angle.

### `radius_limit`
if checked, the bevel radius can't be greater than the length of the edge.

### `adjust_limit`
adjust the "radius_limit".
when the value is 1, the max bevel radius is limited by the shortest edge.
when the value is 0.5, the max radius is limited to half the length of the shortest edge. which is prevent adjacent bevels crosses. it's the default value.
when the value is 0, no bevel.

### `bevel_radius`
specify bevel radius.
you can input an array to define each radius or a single value to all.

### `bevel_distance`
specify bevel distance.
you can input an array to define each distance or a single value to all.

### `max_radius` and `min_radius`
define the maximum and minimum radius.
both can be 0. if the max_radius is 0, it means "no bevel".
the max_radius is limited by the radius_limit.

### `bevel_threshold`
0~180 degrees.
angles below this value will be beveled. default is 150.
you can input an array to define each threshold or a single value to all.

### `circle_scope`, `bisector_scope`, `arc_scope`
diagnostic options.