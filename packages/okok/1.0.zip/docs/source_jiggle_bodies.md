Creates sources for **simulate_jiggle**. This compound comes in 2 forms. Similar to standard sources **source_jiggle_bodies** takes an array of objects for creating multiple bodies at once.

There's also **source_jiggle_body** which only takes a single points input. The difference is **Spring Properties** are auto ports which can take an array for setting per-point values. Its still possible to do per-point spring properties with **source_jiggle_bodies**, it just requires doing so manually with **set_geo_property**<br />

### <span style="color:#90A3F4">points</span>
Input points geometry that will be directly converted to body of connected particles for the simulation. If the desired input is a mesh, pass it into a **mesh_to_jiggle_points** and use that as the input geometry for this node.
<br />

## Spring Settings

### <span style="color:#82D99F">connect_distance</span>
Each point will connect to nearby points within this distance. (White circle in diagnostic view)
<br />

### <span style="color:#82D99F">spring_coeff</span>
How strongly the springs push/pull.
<br />

### <span style="color:#82D99F">spring_smooth</span>
Smoothing averages velocity across nearby points to reduce jitter.
<br />

### <span style="color:#82D99F">smooth_radius</span>
Smoothing radius as a multiple of **connect_distance**. (Blue circle in diagnostic view)
<br />

### <span style="color:#82D99F">spring_damp</span>
Dampening slows particles under heavy acceleration from springs, akin to viscosity for a fluid.
<br />

## Misc

### <span style="color:#82D99F">inherit_velocity</span>
Inherit velocity from the source.
<br />

### <span style="color:#82D99F">particle_bounciness</span>
Standard particle bounciness. Usually this has little effect as the springs in the body make it inherently bouncy.
<br />

### <span style="color:#62CFD9">diagnostic_point_id</span>
Determines which point to highlight in diagnostic view.
<br />

### <span style="color:#90A3F4">constraint</span>
This input can be used with **make_jiggle_constraint** for constraining jiggle bodies to a mesh.
<br />
