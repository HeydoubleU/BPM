Combines the stock **file_cache** node with **memory_cache** from the rebel compounds pack. Parameters are the same but with an additional **Memory Cache** section.

## Memory Cache

<br>The memeory cache will be flushed if any of the follow conditions are met:

* The graph is recompilled, ie. changes are mode to this node, or any upstream/downstream connections.<br>
* The current time is outside **active_frame_range** (only if its enabled).<br>
* **only_in_order** is enabled and its conditions are met.

### use_memory_cache

Whether or not to load the file cache into memory. Disabled, this compound will behaive like the stock **file_cache** node.
* Enable this and set **mode** to *'passthrough'* to cache the input objects to memory without writing files.

### only_in_order

Flushes the cache if uncached frames are skipped, either during playback or scrubbing.

### Daignostics

Visual feedback on if the current frame is cached. Note: enabling this overrides the **color** property.<br>

____

#### WARING:

This compound depends multiple experimental nodes, use with caution.