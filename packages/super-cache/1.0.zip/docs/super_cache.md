Combines the standard file cache with rebel-pack's memory cache. For lookdev the default mode is set to _Passthrough_ so the input only caches to memory, the mode can be switched to write and played through to write the memory cache to files.

The memory cache is only flushed via **edit > Reset Feedback State** or when the graph re-compiles.

Or disable **use memory cache** and this compound behaves like a normal **file_cache**