Scale or set each hair's length.

## Inputs

### base_scale
The base *scaling factor*.

### absolute
Set hairs' length to be exactly the *scaling factor* instead of scaling by it

## randomize
Multiplies the *scaling factor* by a random value for each hair

## Sample Mesh Properties

Sample properties from a mesh onto the hair.

### source_mesh
Mesh to sample properties from, this should the the same **source_mesh** the hair was created from..

### scale_property
Multiplies the *scaling factor* by sample data from this property.

### mask_property
Sample data from this property masks the areas this node affects.