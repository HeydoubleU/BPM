# `pie_piece`

版本：6
最后更新：2021-5-7
作者：g2mXagent@ya.ru

程序化餅塊。

## 輸入

### `Export_Strand`

勾選輸出 Strand 參考線。

### `Export_Mesh`

勾選才會輸出模型。

### `start_angle`

開始角度

### `pie_angle`

餅塊的角度

### `sides`

餅塊的邊數。值越大模型越平滑

### `inner_radius`

內環半徑。

### `outer_radius`

外環半徑。

### `gap_width`

餅塊間隙寬度。

### `extrude`

擠出高度。

### `bisector_offset`

使餅塊在角平分線上移動。

### `y_offset`

餅塊在 Y 軸移動。

## 輸出

### `out_geometry`

餅圖模型

### `out_strands_guide`

strand 參考線。

