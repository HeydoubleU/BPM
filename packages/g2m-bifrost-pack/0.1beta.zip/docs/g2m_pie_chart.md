# `g2m_pie_chart`

最后更新：2022-02-19
作者：g2mXagent@ya.ru

程序化餅圖。

## 輸入

### `Export_Mesh`

勾選才會輸出模型。

### `start_angle`

餠圓的起始角度。0 表示從 X+ 方向逆時針轉。

### `full_moon_angle`

餅圓完整角度。默認 360

### `per_90d_sides`

每90度餠的邊數。值越大模型越平滑。一般 12 足以。小於 1 餠消失。

### `piece_value`

每個餅塊的值，自動計算百分比。數組中每個值對應一個餅塊。大於 0 的值才有效。
* 僅接受 float 或 float array 數據。其他數據將被忽略，從而使用默認值。（下同）

### `outer_radius`

外環半徑。

### `inner_radius`

內環半徑。

### `gap`

餅塊間隙寬度。

### `extrude`

擠出高度。

### `piece_sweep`

餅塊完整度。值介於 0~1 之間。1 表示完整的餅塊，0 表示沒有餅塊。

### `piece_anti_sweep`

餅塊完整度。值介於 0~1 之間。0 表示完整的餅塊，1 表示沒有餅塊。

### `bisector_offset`

使餅塊在角平分線上移動。

### `y_offset`

餅塊在 Y 軸移動。

### `hsv_color`

餅塊的 HSV 顔色值。HSV 表示色相、飽和度和亮度值。介於 0～1
* 默認爲彩虹色

### `outline_hsv_color`

輪廓線顔色。

### `outline_width`

輪廓線寬度。

## 輸出

### `pie_geo`

餅圖模型

### `outline`

輪廓線

