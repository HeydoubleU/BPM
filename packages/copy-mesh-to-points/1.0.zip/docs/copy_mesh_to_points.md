Copies input mesh(es) to points and outputs a single mesh so it can for example be written to alembic or converted to a Maya mesh. A similar result can be achieved with instances and **bake_instanced_geometry**, but this compound uses a different method which is usually significantly faster, especially when copying low poly meshes onto many points.

### <span style="color:#E69963">instance_id_from_id</span>
Just like instancing, the **point_instance_id** property is used to determine which of the input mesh (if there's more than 1) gets copied to the point. Enabling this option uses **point_id** instead, for example if the input points are from a particle sim with **label_point_id** enabled.
<br />

### <span style="color:#D9BE6C">point_properties</span>
A space separated list of properties on the points to transfer to the copied meshes.
<br />

### <span style="color:#E69963">transfer_normals</span>
Include normals when copying meshes. Disabling improves performance.
<br />

### <span style="color:#E69963">transfer_uvs</span>
Include UVs when copying meshes. Disabling improves performance.
<br />

### <span style="color:#D9BE6C">mesh_properties</span>
A space separated list of properties on the input mesh(es) to include when copying.
<br />

## Optimize

### <span style="color:#E69963">store_meshes</span>
Stores/caches input meshes on the given frame. Enabling this can slightly improve performance with high-poly meshes.
<br />

### <span style="color:#E69963">bypass</span>
Bypass construction of data about given component type. This is needed for transferring properties, but data for all component types is not always needed in which case it can be bypassed for slightly better performance.
<br />

### <span style="color:#62CFD9">points_per_chunk</span>
How many points get processed at once per thread. At 0 the value will be calculated automatically from the inputs, but experimenting with different values may result in slightly better performance.
<br />