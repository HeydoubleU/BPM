## cloud_painter Graph

### What it does

This graph uses a locator which is then connected to the cloudPainter bifrost graph via: `connectAttr locator1.translate cloudPainter.position`; The locator updates the position of an internal create_mesh_sphere which provides the shape to draw out the cloud shapes. The shapes that are drawn are then converted to a volume which creates the appearance of a cloud. If the browser example is opened rather than imported then the locator is provided for you.

### Inputs and outputs 

Inputs for this graph include a regenerate_cloud boolean toggle, a version_num input for the cached file version number and a Position x,y,z inputs which get connected to a Maya locator. The output is the resulting paint_output(bifShape1 - the result of the paint stroke in the VP) and the cloud_gen_output (bifShape2 - the resulting generated volume cloud).  

### Useful information

- this graph was last updated using Maya 2019 with MtoA 4.0.1 (downloaded from MtoA downloads page) and Bifrost 2.0.4.0 (downloaded from the AREA).

- You will need to input a custom path to write/read the cache file to. By default the path is writing out to the system $HOME directory (such as /Users/yourUsername (on Mac)). The graph has a internal compound called fileName_and_Dir which takes a Filename Prefix input and a Directory String (user specified path goes here).

- The paint system operates off of a feedback which accumulates the stroke. Feedback is sensitive to graph changes where ones results can easily be flushed. Therefore the system uses a logic structure to write out a cache file if the time is 0. If it is not 0, the user can paint without writing out the cache. Once you are happy with the cloud shape painted, use the 'set current time' input to the right of the Maya timeline to input a value of 0. This will write the cache. Then press rewind to set the current time back to 1. There is an input on the graph called regenerate_cloud. Typically regenerate_cloud should be off until you want to generate the stroke you had just painted. Set regenerate_cloud to 1 to produce the volumetric cloud in the VP. The volumetric cloud reads a .bob cache file that was written out when we set the current time to 0 and then converts it to a volume. 

- To flush the current stroke, set the locator back to 0, 0, 0 and then check on then off the length_toggle parameter on the paint_cloud_system compound (which does forces a graph recompile).

- The graph contains a compound inside the paint_cloud_system that oscillates the painting object scale (it offers a length_toggle switch for uniform and non uniform oscillation, as well as a magnitude input)

- The graph also contains a compound inside the paint_cloud_system that produces noise on the paint object surface. This breaks up the stroke to look less sphere like. The noise parameters are available to you to modify.

- NOTE when regenerate_cloud is off you may get a Warning returned in the script editor stating "Cannot draw an object with no points". This is due to the regenerate_cloud switch using an empty bifrost object in its false case. It should not be a concern.

- The graph does contain a referenced aiStandardVolume material (MtoA 4.0.1 for Maya 2019). It also uses a set_Arnold_volume_settings compound with a volume padding set to 10. Depending on scene scale this value may need to be increased to avoid blocky artifacts in the Arnold render. The aiStandardVolume also has aiNoise plugged into the displacement attribute of the volume shader for additional detail.

- The render setting samples are low so you will need to adjust for a higher quality render result. Feel free to also change the lighting.

### Example scene

- Example scene is included. locator1 is already connected to the graph.

- To use, open the example scene and start moving the locator1 object in x, y, z (center transform handle). Experiment with how the stroke builds up by employing fast vs. slow movements and broad vs consolidated circular movements. Once you are happy with the stroke, set the current time to 0 using the input field to the right of the timeline. This writes out the cache. Then press rewind. Select the bifrostGraph node in the outliner and check on Regenerate Cloud. The volume should appear in the VP.
