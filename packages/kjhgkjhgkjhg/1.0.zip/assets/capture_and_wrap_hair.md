This node mainly pertains to animation. By default the hair is created and all modifiers recalculated every frame. This can be slow and may jittering or cause other problems if the hairs' **source_mesh** has animation.
<br>This node captures the hair object so nothing before it has to be recalculated, and wraps/pins each hair to the **source_mesh** on subsequent frames.

* NOTE: **collide_hair_modifier**, **wind_hair_modifier**, and other dynamic/animated nodes must come after this in order to continuously update the hair.

### reference_frame
Whenever the graph is recompiled the hair object is created and captured regardless of the current frame. This value determines what frame that capture can be updated on.
