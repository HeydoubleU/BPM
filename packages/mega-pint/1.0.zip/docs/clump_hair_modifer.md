Deforms hair into clumps

## Inputs

### clump_source
Object to generate clumps from. This can be a points object in which case clumps will form at each point position, or a strand object such as the hair's guide curves. A strand object offers more control as the clump's shape contour to the strand, but the point count per strand must be constant and equal to the hairs' point count per strand.

## Settings

### strength_along_hair
Amount of influence the clump has over the length of each hair.

### seed
seed used for the various random functions in this compound

## Clumping

### clumping_strength
Overall clumping strength, negative values will push clumps apart.

### clump_random
Multiply the **clump_strength** by a random value per clump.

### clamp_clump_strength
Limits the final clumping strength to **1**, as values greater than **1** will cause hairs in a clump to intersect each other.

## Twist

### twist_clumps
Disabling will offer a small performance improvement if twist is not required.

### twist_amount
How much to twist each clump in degrees.

### random_direction
You may require some clumps twist in one direction and some in the other. One way to achieve this would be to enable **twist_random** with a range of -1 to 1. This will result in clumps twisting both directions but many will have close to no twist. An alternative is to enable this option and use a narrow random range ie. 0.8 to 1. Clumps will have a consistent amount of twist, only for each their direction will be randomly reversed.

### mask_by_clump_strength
Clumps with a low **clumping_strength** but a large amount of twist tend to look unnatural and may come up when using wide random ranges. Enabling this option will multiply the twist amount by the clump strength, dampening the amount of twist on loose clumps.

## Sample Mesh Properties
Sample properties from a mesh to scale the **clump_strength** and or **twist_amount** by. Typically this would be the hair's **source_mesh**, in the case of sampling clump or twist properties this may also be any separate mesh.