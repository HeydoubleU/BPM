# `sort_array_and_remove_duplicates`

Returns an array with duplicates removed - an array containing each unique value exactly once, sorted. 

## Example

If the following array is the input: `[12, 10, 10, 13, 12]`

The result is this:  `[10, 12, 13]`

