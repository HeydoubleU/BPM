# `disconnect_mesh_faces`

This creates a mesh where faces no longer share vertices, each face is disconnected. This means the new mesh will a point for each face-vertex of the old mesh.

