This is a **simulate_particles** node modified for simulating jiggly materials.

The inputs work the with standard colliders, influences, ect. with the exception of sources. Only **source_jiggle_body/bodies** should be used with the sources input. Otherwise right clicking each port will show suitable inputs.