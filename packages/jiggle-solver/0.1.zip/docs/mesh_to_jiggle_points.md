Converts meshes into points to be used with **source_jiggle_body**.<br />

### <span style="color:#82D99F">auto_size_bias</span>
Base detail size is determined by edge lengths so that the resulting point cloud density is appropriate for the input mesh. **auto_size_bias** of 0 means the min edge is used, a value of 1 means the max is used.
<br />

### <span style="color:#82D99F">outer_point_size</span>
Size multiplier for outer points. Outer points are created directly from the mesh vertices. These are used to deform the mesh so it moves with the jiggle body. (Setting this to a negative value essentially disables collision for these points which can be useful for simulations with self collision).
<br />

### <span style="color:#82D99F">inner_point_size</span>
Size multiplier for inner points. Inner points fill the mesh to give structure and prevent it from collapsing.
<br />

### <span style="color:#82D99F">inner_offset</span>
Surface offset for where inner points can be created. 
<br />

## <span style="color:#90A3F4">Volume Conversion</span>
Settings for the mesh to volume conversion from which inner points are created. <span style="color:#82D99F">**detail_size**</span> in this case is a multiplier of the automatic base detail size.

## <span style="color:#E69963">Scatter</span>
Inner points can be constructed from the volume voxel positions, or by scattering points inside the volume. The better method just depends on the input mesh and desired result.

### <span style="color:#82D99F">packing_scale</span>
The amount of points scattered into the volume. Values greater than 1 may result in overlapping points.
<br />

### <span style="color:#E69963">cull_overlapping</span>
Removes overlapping points (applies to inner points only). This can be used in combination with an increased **packing_scale** to get a denser non-overlapping point cloud. Although it takes a **packing_scale** of 3-4 or higher to start having a noticeable effect, and values just over 1 might actually result in a reduced point count.
<br />

### <span style="color:#82D99F">overlapping_radius</span>
Multiple of the point size for what's considered overlapping.
<br />