Creates constraint object for use with **source_jiggle_bodies**. The resulting bodies move as if attached to the constraint object.

### <span style="color:#90A3F4">mesh</span>
Mesh which the jiggle bodies will be attached to.
<br />

## Base Properties
These inputs connect to their respective **set_geo_property**, so they can optionally take an array for setting per-point values.

### <span style="color:#82D99F">weight</span>
Overall influence of the constraint
<br />

### <span style="color:#82D99F">falloff_range</span>
Distance over which the constraint's influence falls to 0.
<br />

### <span style="color:#82D99F">falloff_exp</span>
Exponent of the falloff curve. A value of 1 means a linear falloff, higher values result in a faster falloff, lower values slower. 
<br />

## Hard Properties
<span style="color:#E69963">Hardening</span> is a second set of properties (typically higher than the base) that are blended to at high velocity, this allows fast moving constraints without causing excessive jiggling.
<br />

### <span style="color:#A8D977">harden_velocity</span>
The range of velocity magnitudes over which hardening takes effect. At velocity under the range the **base properties** are used. As velocity increases through the range the constraint properties are interpolated from the base, to the **hard properties**.
<br />

## Misc

### <span style="color:#E69963">compute_tangents</span>
Face tangents are needed to correctly transform particles with deforming or rotating constraint mesh. This should only be disabled if the input mesh is static or already has face_tangent.
<br />

### <span style="color:#E69963">compute_velocity</span>
Compute velocity for the input mesh. This should only be disabled if the mesh is static or already has point_velocity.
<br />

### <span style="color:#82D99F">velocity_transfer</span>
Transfer constraint's velocity to the attached particles.
<br />

