### What is BPM (Bifrost Package Manager)
BPM is an interface accessible directly within Maya for sharing Bifrost content in the form of "packages".
A package is simply a folder of one or more Bifrost compounds and supporting content, icons, documentation, graphs, etc.<br /><br />
Distributing Bifrost content via a package manager comes with a number of advantages:
- &nbsp;&nbsp;Discoverability
- &nbsp;&nbsp;Simplified install
- &nbsp;&nbsp;Publishers can update packages and users are automatically notified
- &nbsp;&nbsp;Packages can rely on one or many other packages, and these dependencies will automatically be installed when needed
<br />
### How to Create and Publish a Package
tbd