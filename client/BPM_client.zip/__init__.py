from . import UI, IO

__version__ = '0.2'


def start(first_time=False):
    if first_time:
        UI.shelfDialog()

    UI.closeBPM()
    UI.openBPM()
