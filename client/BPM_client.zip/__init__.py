__version__ = '1.0.2'
from . import UI, IO


def start(first_time=False):
    if first_time:
        UI.shelfDialog()

    UI.closeBPM()
    UI.openBPM()


def installPackage(package, version=''):
    package_set_and_info = IO.extendPackageSetToDependencies({(package, version)})
    IO.filterPackageSet(package_set_and_info[0])
    print('Installing package and dependencies')
    IO.installPackageSet(*package_set_and_info)
