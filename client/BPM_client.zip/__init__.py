from . import UI

__version__ = '1.0.0'


def start(first_time=False):
    if first_time:
        UI.shelfDialog()

    UI.closeBPM()
    UI.openBPM()
