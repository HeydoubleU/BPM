from . import UI, IO

__version__ = '0.1.0'
version_checked = False


def start():
    UI.openBPM()

    global version_checked
    if not version_checked:
        version_checked = True
        checkForUpdates()


def checkForUpdates():
    client_info = IO.getClientInfo()
    if client_info['version'] == __version__:
        return

    if not UI.updateDialog(__version__, client_info['version']):
        return

    UI.closeBPM()
    IO.replaceClient()
    exec(client_info['reload_script'])
