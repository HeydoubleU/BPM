import json
import time

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
import maya.cmds as mc
import maya.mel as mel

from . import common as cmn
from . import IO, threads


class PackageSearchWindow(QMainWindow):
    package_set_and_info = ()
    updates_available = False

    def __init__(self):
        super(self.__class__, self).__init__(cmn.mayaWin())
        self.setWindowFlags(self.windowFlags() | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedWidth(10)
        self.setMaximumHeight(400)

        self.open_anim = QVariantAnimation(duration=100, startValue=10, endValue=320, easingCurve=QEasingCurve.OutCirc)
        self.open_anim.valueChanged.connect(self.openAnimTick)

        self.height_anim = QVariantAnimation(duration=100, startValue=10, endValue=320, easingCurve=QEasingCurve.OutCirc)
        self.height_anim.valueChanged.connect(lambda x: self.resize(0, x))

        style = str(open(f'{cmn.MP}/resources/styling.qss', "r").read())
        self.setStyleSheet(style)

        self.setCentralWidget(QWidget())
        self.centralWidget().setLayout(QVBoxLayout(spacing=0))
        self.centralWidget().layout().setContentsMargins(0, 0, 0, 0)

        self.search_wig = QWidget()
        self.search_wig.setLayout(QHBoxLayout(spacing=0))
        self.search_wig.layout().setContentsMargins(0, 0, 0, 0)
        self.centralWidget().layout().addWidget(self.search_wig)

        self.search_line = QLineEdit()
        self.search_line.setPlaceholderText('Search for Package...')
        self.search_wig.layout().addWidget(self.search_line, alignment=Qt.AlignTop)

        self.more_btn = QPushButton(fixedSize=QSize(42,42), checkable=True)
        self.more_btn.setIconSize(QSize(42, 42))
        self.more_btn.setIcon(QPixmap(cmn.MP + '/resources/icons/more.png'))
        self.more_btn.clicked.connect(self.toggleMore)
        self.search_wig.layout().addWidget(self.more_btn)

        self.more_wig = QWidget()
        self.more_wig.setLayout(QHBoxLayout(spacing=0))
        self.more_wig.layout().setContentsMargins(0, 0, 0, 0)
        self.search_wig.layout().addWidget(self.more_wig)
        self.more_wig.hide()

        self.installed_btn = QPushButton('Installed', checkable=True, objectName='MiscBtn', fixedHeight=42)
        self.installed_btn.clicked.connect(self.listInstalled)
        self.more_wig.layout().addWidget(self.installed_btn)

        self.updates_btn = QPushButton('Updates', checkable=True, objectName='MiscBtn', fixedHeight=42)
        self.updates_btn.clicked.connect(self.listUpdates)
        self.more_wig.layout().addWidget(self.updates_btn)

        btn = QPushButton('Reload Bifrost', objectName='MiscBtn', fixedHeight=42)
        btn.clicked.connect(reloadWithWarning)
        self.more_wig.layout().addWidget(btn)

        self.search_tree = QTreeWidget()
        self.centralWidget().layout().addWidget(self.search_tree)
        self.search_tree.hide()
        self.search_tree.setRootIsDecorated(False)
        self.search_tree.setHeaderHidden(True)
        self.search_tree.setSelectionMode(QTreeWidget.NoSelection)
        self.search_tree.setFocusPolicy(Qt.NoFocus)
        self.search_tree.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.search_tree.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)

        self.search_thread = threads.PackageSearcher()
        self.search_thread.lineEdit = self.search_line
        self.search_thread.client_update.connect(clientUpdateDialog)
        self.search_thread.package_update.connect(self.notifyUpdate)
        self.search_thread.matches_found.connect(self.updateSearchList)
        self.search_thread.start()

        self.status_line = QTextEdit(readOnly=True, minimumHeight=160)
        self.status_line.setFocusPolicy(Qt.NoFocus)
        cmn.STATUS_LINE = self.status_line
        self.centralWidget().layout().addWidget(self.status_line)
        self.status_line.hide()

        # Install Buttons
        self.install_btns_wig = QWidget()
        layout = QHBoxLayout(spacing=4)
        layout.setContentsMargins(4,4,4,4)
        self.install_btns_wig.setLayout(layout)
        self.centralWidget().layout().addWidget(self.install_btns_wig)
        self.install_btns_wig.hide()

        btn = QPushButton('Cancel', objectName='MiscBtn', fixedHeight=24)
        btn.clicked.connect(self.cancelInstall)
        layout.addWidget(btn)

        btn = QPushButton('Install', objectName='InstallBtn', fixedHeight=24)
        btn.clicked.connect(self.execInstall)
        layout.addWidget(btn)

        # Post install buttons
        self.post_install_btns_wig = QWidget()
        layout = QHBoxLayout(spacing=4)
        layout.setContentsMargins(4, 4, 4, 4)
        self.post_install_btns_wig.setLayout(layout)
        self.centralWidget().layout().addWidget(self.post_install_btns_wig)
        self.post_install_btns_wig.hide()

        btn = QPushButton('Close', objectName='MiscBtn', fixedHeight=24)
        btn.clicked.connect(self.close)
        layout.addWidget(btn)

        btn = QPushButton('Back', objectName='MiscBtn', fixedHeight=24)
        btn.clicked.connect(self.cancelInstall)
        layout.addWidget(btn)

        btn = QPushButton('Reload Bifrost', objectName='MiscBtn', fixedHeight=24)
        btn.clicked.connect(reloadWithWarning)
        layout.addWidget(btn)

        # Update Buttons
        self.update_btns_wig = QWidget()
        layout = QHBoxLayout(spacing=4)
        layout.setContentsMargins(4, 4, 4, 4)
        self.update_btns_wig.setLayout(layout)
        self.centralWidget().layout().addWidget(self.update_btns_wig)
        self.update_btns_wig.hide()

        btn = QPushButton('Cancel', objectName='MiscBtn', fixedHeight=24)
        btn.clicked.connect(self.listInstalled)
        layout.addWidget(btn)

        btn = QPushButton('Update', objectName='InstallBtn', fixedHeight=24)
        btn.clicked.connect(self.prepareUpdate)
        layout.addWidget(btn)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.close()
            return
        super(self.__class__, self).keyPressEvent(event)

    def showEvent(self, event):
        super(self.__class__, self).showEvent(event)
        self.resize(0, 0)
        self.open_anim.start()

    def openAnimTick(self, value):
        self.setFixedWidth(value)
        self.resize(0, 0)

    def updateSearchList(self, matches):
        self.search_tree.clear()
        if matches:
            self.search_tree.show()

            for match in matches:
                item = QTreeWidgetItem()
                self.search_tree.addTopLevelItem(item)
                self.search_tree.setItemWidget(item, 0, PackageWidget(match, item))

            self.autoResize()

        else:
            self.search_tree.hide()
            self.autoResize()

    def autoResize(self):
        QApplication.processEvents(QEventLoop.AllEvents, 200)
        a = self.height()
        self.height_anim.setStartValue(a)
        self.resize(0,0)
        b = self.search_tree.verticalScrollBar().maximum() + self.height()
        self.height_anim.setEndValue(b)
        self.resize(0, b)

        self.height_anim.start()

    def toggleMore(self, state):
        if state:
            self.more_btn.setIcon(QPixmap(cmn.MP + '/resources/icons/back.png'))
            self.search_line.hide()
            self.more_wig.show()
            self.search_tree.show()
            if self.updates_available:
                self.listUpdates()
            else:
                self.listInstalled()

        else:
            self.more_btn.setIcon(QPixmap(cmn.MP + '/resources/icons/more.png'))
            self.more_wig.hide()
            self.search_tree.clear()
            self.search_tree.hide()
            self.update_btns_wig.hide()
            self.search_line.setText('')
            self.search_line.show()

            self.autoResize()

    def listInstalled(self):
        self.installed_btn.setChecked(True)
        self.updates_btn.setChecked(False)

        self.update_btns_wig.hide()
        self.search_tree.clear()
        IO.updateLocalPackageSet()
        if not IO.LOCAL_PACKAGE_SET:
            item = QTreeWidgetItem()
            item.setText(0, '  No Packages Installed')
            self.search_tree.addTopLevelItem(item)

        for package in IO.LOCAL_PACKAGE_SET:
            item = QTreeWidgetItem()
            self.search_tree.addTopLevelItem(item)
            self.search_tree.setItemWidget(item, 0, LocalPackageWidget(package, item))

        self.autoResize()

    def listUpdates(self):
        self.installed_btn.setChecked(False)
        self.updates_btn.setChecked(True)
        self.search_tree.clear()
        updates_available = False

        for version_type, update_set in zip(('Minor', 'Major'), IO.checkForUpdates()):
            if not update_set:
                continue
            updates_available = True
            self.addTextTreeItem(f'  {version_type} Version Updates:')
            for package, new_version, old_version in update_set:
                item = QTreeWidgetItem()
                self.search_tree.addTopLevelItem(item)
                self.search_tree.setItemWidget(
                    item, 0, UpdatePackageWidget(package, new_version, old_version, version_type=='Minor'))

        if updates_available:
            self.update_btns_wig.show()
        else:
            self.addTextTreeItem(f'  No Updates Available')
        self.autoResize()

    def prepareUpdate(self):
        cmn.updateStatus(f'Update Packages...')

        package_set = set()
        for x in range(self.search_tree.topLevelItemCount()):
            item = self.search_tree.topLevelItem(x)
            wig: UpdatePackageWidget = self.search_tree.itemWidget(item, 0)
            if type(wig) is UpdatePackageWidget and wig.check_box.isChecked():
                package_set.add(wig.package_tuple)

        self.prepareInstallFromSet(package_set)

    def prepareInstallFromSet(self, package_set):
        self.search_tree.clear()
        self.search_tree.hide()
        self.search_wig.hide()
        self.update_btns_wig.hide()
        self.status_line.show()
        self.autoResize()

        cmn.updateStatus('Preparing Install...')

        self.package_set_and_info = IO.extendPackageSetToDependencies(package_set)

        cmn.updateStatus('\n- Packages and Dependencies -\n', pre_line=True)
        cmn.STATUS_INDENT = 4

        IO.filterPackageSet(self.package_set_and_info[0])

        for package, version in self.package_set_and_info[0]:
            cmn.updateStatus(f'{package} {version}')

        cmn.updateStatus('')
        cmn.STATUS_INDENT = 0

        self.install_btns_wig.show()

    def execInstall(self):
        if not self.package_set_and_info:
            return
        self.install_btns_wig.hide()
        QApplication.processEvents(QEventLoop.AllEvents, 200)

        IO.installPackageSet(*self.package_set_and_info)
        self.package_set_and_info = ()
        self.post_install_btns_wig.show()

    def cancelInstall(self):
        self.close()
        openBPM()

    def addTextTreeItem(self, text):
        item = QTreeWidgetItem()
        item.setText(0, text)
        self.search_tree.addTopLevelItem(item)

    def notifyUpdate(self):
        self.updates_available = True
        self.more_btn.setIcon(QPixmap(cmn.MP + '/resources/icons/update.png'))


class PackageWidget(QWidget):
    def __init__(self, package, tree_item: QTreeWidgetItem, *args, **kwargs):
        super(self.__class__, self).__init__(*args, objectName='PackageWidget', **kwargs)
        self.package = package
        self.tree_item = tree_item
        self.setLayout(QGridLayout(spacing=0))
        self.layout().setContentsMargins(0, 0, 0, 0)

        btn = QPushButton('    '+package, fixedHeight=36)
        self.layout().addWidget(btn, 0, 0)
        btn.clicked.connect(lambda: BPM_WINDOW.prepareInstallFromSet({(package, '')}))

        wig = QWidget()
        wig.setAttribute(Qt.WA_TranslucentBackground)
        wig.setLayout(QHBoxLayout(spacing=0))
        wig.layout().setContentsMargins(0,0,0,0)
        self.layout().addWidget(wig, 0, 0, alignment=Qt.AlignRight)

        btn = QPushButton(flat=True, fixedSize=QSize(36, 36), iconSize=QSize(36, 36), objectName='VersionsBtn')
        btn.clicked.connect(lambda: DescriptionWindow(package))
        btn.setIcon(QPixmap(f'{cmn.MP}/resources/icons/info.png'))
        wig.layout().addWidget(btn)

        btn = QPushButton(flat=True, checkable=True, fixedSize=QSize(36, 36), iconSize=QSize(36, 36), objectName='VersionsBtn')
        btn.clicked.connect(self.toggleVersions)
        btn.setIcon(QPixmap(f'{cmn.MP}/resources/icons/versions.png'))
        wig.layout().addWidget(btn)

    def toggleVersions(self, state):
        if state:
            self.tree_item.setExpanded(True)

            if not self.tree_item.childCount():
                pack_info = IO.getPackageInfo(self.package)

                for version in pack_info['versions']:
                    item = QTreeWidgetItem()

                    self.tree_item.insertChild(0, item)

                    btn = QPushButton(version, fixedHeight=30, objectName='VersionBtn')
                    btn.clicked.connect(lambda x=None, y=version:
                                        BPM_WINDOW.prepareInstallFromSet({(self.package, y)}))
                    BPM_WINDOW.search_tree.setItemWidget(item, 0, btn)
        else:
            self.tree_item.setExpanded(False)

        BPM_WINDOW.autoResize()


class LocalPackageWidget(QWidget):
    def __init__(self, package, tree_item):
        super(self.__class__, self).__init__(objectName='PackageWidget')
        self.path = IO.LOCAL_PACKAGE_PATHS[package]
        self.tree_item = tree_item
        self.setLayout(QGridLayout(spacing=0))
        self.layout().setContentsMargins(0, 0, 0, 0)

        label = QLabel(f'    {package[0]} {package[1]}', fixedHeight=36)
        self.layout().addWidget(label, 0, 0)

        btn = QPushButton(flat=True, fixedSize=QSize(36, 36), iconSize=QSize(36, 36), objectName='VersionsBtn')
        btn.clicked.connect(lambda: DescriptionWindow(package[0]))
        btn.setIcon(QPixmap(f'{cmn.MP}/resources/icons/info.png'))
        self.layout().addWidget(btn, 0, 0, alignment=Qt.AlignRight)

        btn = QPushButton(fixedSize=QSize(36, 36), iconSize=QSize(36, 36), objectName='VersionsBtn')
        btn.setIcon(QPixmap(f'{cmn.MP}/resources/icons/trash.png'))
        btn.clicked.connect(self.removePackage)
        self.layout().addWidget(btn, 0, 1)

    def removePackage(self):
        QFile(self.path).moveToTrash()
        BPM_WINDOW.search_tree.takeTopLevelItem(BPM_WINDOW.search_tree.indexOfTopLevelItem(self.tree_item))
        BPM_WINDOW.autoResize()


class UpdatePackageWidget(QWidget):
    def __init__(self, package, new_version, old_version, checked=False):
        super(self.__class__, self).__init__(objectName='PackageWidget')
        self.package_tuple = (package, new_version)
        self.setLayout(QHBoxLayout(spacing=6))
        self.layout().setContentsMargins(0, 0, 0, 0)

        label = QLabel(f'    {package} {new_version}', fixedHeight=36)
        self.layout().addWidget(label)

        label = QLabel(f'    (current {old_version})', fixedHeight=36, objectName='SubHeader')
        self.layout().addWidget(label)

        self.layout().addStretch()

        btn = QPushButton(flat=True, fixedSize=QSize(36, 36), iconSize=QSize(36, 36), objectName='VersionsBtn')
        btn.clicked.connect(lambda: DescriptionWindow(package))
        btn.setIcon(QPixmap(f'{cmn.MP}/resources/icons/info.png'))
        self.layout().addWidget(btn, alignment=Qt.AlignRight)

        self.check_box = QCheckBox(fixedSize=QSize(36, 36))
        self.check_box.setChecked(checked)
        self.layout().addWidget(self.check_box, alignment=Qt.AlignRight)


class DescriptionWindow(QWidget):
    def __init__(self, package):
        super(self.__class__, self).__init__(BPM_WINDOW, Qt.Window)
        self.setWindowTitle('Package Description')
        desc = IO.getPackageDesc(package)
        self.setLayout(QVBoxLayout(spacing=8))

        layout = QHBoxLayout()
        layout.addWidget(QLabel(package.replace('-', ' ').title(), objectName='Header'))
        layout.addWidget(QLabel(' created by ' + desc['creator'], objectName='SubHeader'))
        layout.addStretch()
        self.layout().addLayout(layout)

        def addLine(layout, name=''):
            frame = QFrame(objectName=name)
            frame.setFrameShape(QFrame.HLine)
            frame.setFixedHeight(1)
            layout.addWidget(frame)

        addLine(self.layout(), 'Separator')
        self.layout().addWidget(QLabel(text=desc['description'], objectName='Description', wordWrap=True))
        self.layout().addSpacing(10)
        self.layout().addWidget(QLabel('Releases:'))

        versions_scroll = QScrollArea()
        versions_scroll.setWidgetResizable(True)
        versions_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        versions_layout = QVBoxLayout()
        wig = QWidget(objectName='Version')
        wig.setLayout(versions_layout)
        versions_scroll.setWidget(wig)
        self.layout().addWidget(versions_scroll)

        for version, version_desc in desc['versions'].items():
            layout = QHBoxLayout()
            versions_layout.addLayout(layout)
            addLine(versions_layout)
            layout.addWidget(QLabel(f'{package} {version}', objectName='VersionHeader'))
            layout.addWidget(QLabel(f"•   {version_desc['date']}", objectName='VersionSubHeader'))
            # layout.addWidget(QLabel(f"•   {version_desc['by']}   •   {version_desc['date']}", objectName='VersionSubHeader'))
            layout.addStretch()

            versions_layout.addWidget(QLabel(version_desc['release_notes']+'\n', objectName='VersionDescription', wordWrap=True))
        versions_layout.addStretch()

        self.show()
        self.move(self.pos() - QPoint(160, 160))


BPM_WINDOW: PackageSearchWindow = None


def openBPM():
    global BPM_WINDOW
    BPM_WINDOW = PackageSearchWindow()
    BPM_WINDOW.show()


def closeBPM():
    global BPM_WINDOW
    if BPM_WINDOW:
        BPM_WINDOW.close()
        BPM_WINDOW = None


def clientUpdateDialog(old, new, reload_script):
    dia = QMessageBox()
    dia.setWindowTitle('BPM Update')
    dia.setText(f'Newer BPM Client version available:\n    {old} -> {new}\n\nUpdate now?')
    btn = dia.addButton(QMessageBox.Yes)
    dia.setDefaultButton(btn)
    dia.addButton(QMessageBox.No)
    pos = QCursor.pos() + QPoint(-30, -74)
    dia.move(pos)
    dia.exec_()
    if dia.result() == QMessageBox.Yes:
        closeBPM()
        IO.replaceClient()
        exec(reload_script)
    else:
        cmn.ONCE_FUNCS.append('run')


def shelfDialog():
    dia = QMessageBox()
    dia.setWindowTitle('Create Shelf Button')
    dia.setText(f'Would you like to create a BPM shelf button?')
    dia.addButton(QMessageBox.Yes)
    dia.addButton(QMessageBox.No)
    pos = QCursor.pos() + QPoint(-30, -74)
    dia.move(pos)
    dia.exec_()
    if dia.result() == QMessageBox.Yes:
        mel.eval(f'''
        shelfButton
            -annotation "Open BPM window" 
            -align "center" 
            -label "BPM" 
            -font "plainLabelFont"
            -image "{cmn.MP}/resources/icons/BPM.png" 
            -style "iconOnly"
            -command "import BPM;BPM.start()" 
            -sourceType "python" 
            -parent `tabLayout -q -selectTab $gShelfTopLevel`
        ;
        ''')


def reloadWithWarning():
    if not cmn.hasBeenCalled('reloadBifrostPlugin'):
        dia = QMessageBox()
        dia.setWindowTitle('Reload Warning')
        dia.setText('This function flushes undo and could cause a crash. Use with caution!')
        dia.addButton(QMessageBox.Ok)
        dia.addButton(QMessageBox.Cancel)
        pos = QCursor.pos() + QPoint(-30, -74)
        dia.move(pos)
        dia.exec_()
        if dia.result() != QMessageBox.Ok:
            return

    cmn.reloadBifrostPlugin()
