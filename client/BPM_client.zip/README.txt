Install:

Option 1:

	Execute the following from the script editor (python tab):

from urllib import request; from zipfile import ZipFile
from io import BytesIO; from os import environ

dst = environ["MAYA_APP_DIR"]+'/scripts/BPM'
url = 'https://raw.githubusercontent.com/HeydoubleU/BPM/main/client/BPM_client.zip'
zipfile = ZipFile(BytesIO(request.urlopen(url).read())).extractall(path=dst)
import BPM; BPM.start(True)


Option 2:

	Copy 'BPM' to your maya's scripts folder, then run the following python command:

		import BPM; BPM.start(True)


Usage:

	From the UI you can install, remove, and update packages. It is also possible to install a package with python:
		
		BPM.installPackage("package-name")

	or specify a version with:

		BPM.installPackage("package-name", "version")


	Publishing is done through the BPM discord bot which can be found in the Bifrost Addicts server:

		https://discord.gg/bifrost-addicts

	Message the bot !help for more information on publishing.