import json, sys, os

from PySide2.QtWidgets import QMainWindow, QTextEdit, QApplication
from PySide2.QtCore import QEventLoop

import maya.OpenMayaUI as omui
from shiboken2 import wrapInstance
from maya import cmds as mc

MP = os.path.normpath(os.path.dirname(__file__)).replace('\\', '/')
ONCE_FUNCS = []


def mayaWin():
    mayaMainWindowPtr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(mayaMainWindowPtr), QMainWindow)


def readJson(path):
    with open(path) as file:
        data = json.load(file)
    return data


def writeJson(path, data):
    with open(path, 'w') as file:
        json.dump(data, file, indent=2)


def getCompoundDir():
    if sys.platform == 'win32':
        return f'C:/Users/{os.environ.get("USERNAME")}/Autodesk/Bifrost/Compounds/'
    else:
        return f'{os.path.expanduser("~")}/Autodesk/Bifrost/Compounds/'


def verifyLibrary():
    if not os.path.isdir(BPM_LIB_PATH):
        os.makedirs(BPM_LIB_PATH)

    if not os.path.isdir(BPM_LIB_PATH + '/packages'):
        os.makedirs(BPM_LIB_PATH + '/packages')

    config = {
        "AminoConfigurations": [
            {
                "vendorName": "HeydoubleU",
                "libraryVersion": "0.0.0",
                "libraryName": "BPM",
                "jsonLibs": [
                    {
                        "path": "packages"
                    }
                ]
            }
        ]
    }

    writeJson(BPM_LIB_PATH + '/bifrost_lib_config.json', config)


def updateStatus(text, pre_line=False, post_line=True):
    new_text = STATUS_LINE.toPlainText()
    if STATUS_LINE:

        if pre_line:
            new_text += '\n'

        if STATUS_INDENT:
            new_text += ' ' * STATUS_INDENT

        new_text += text

        if post_line:
            new_text += '\n'

        STATUS_LINE.setText(new_text)
        STATUS_LINE.verticalScrollBar().setValue(STATUS_LINE.verticalScrollBar().maximum())
        QApplication.processEvents(QEventLoop.AllEvents, 200)


def clearStatus():
    STATUS_LINE.setText('')


def hasBeenCalled(func_name):
    if func_name in ONCE_FUNCS:
        return True
    else:
        ONCE_FUNCS.append(func_name)
        return False


def reloadBifrostPlugin():
    tmp = f'{MP}/resources/tmp.ma'
    sn = mc.file(q=True, sn=True)
    if not sn:
        sn = 'untitled.ma'

    mc.file(rename=tmp)
    mc.file(save=True, typ='mayaAscii', force=True)

    nodes = mc.ls(type='bifrostGraphShape') + mc.ls(type='bifrostBoard')
    mc.delete(nodes)
    mc.flushUndo()
    mc.unloadPlugin("bifrostGraph", f=True)
    mc.loadPlugin("bifrostGraph")

    mc.file(tmp, open=True, f=True)
    os.remove(tmp)

    mc.file(rename=sn)


BPM_LIB_PATH = getCompoundDir() + 'BPM'
verifyLibrary()

STATUS_LINE: QTextEdit = None
STATUS_INDENT = 0


