import json, os, re
from urllib import request
from urllib.error import HTTPError
from io import BytesIO
from zipfile import ZipFile
from PySide2.QtCore import QFile

from . import common as cmn





def getClientInfo():
    url = f'https://raw.githubusercontent.com/HeydoubleU/BPM/main/client/client_info.json'
    response = request.urlopen(url)
    return json.loads(response.read())


def replaceClient():
    QFile(cmn.MP).moveToTrash()
    url = f'https://raw.githubusercontent.com/HeydoubleU/BPM/main/client/BPM_client.zip'

    response = request.urlopen(url)
    zipfile = ZipFile(BytesIO(response.read()))
    zipfile.extractall(path=cmn.MP)


def getPackageManifest():  # deprecated, replaced by scrapePackageNames to avoid waiting for github raw to update
    url = f'https://raw.githubusercontent.com/HeydoubleU/BPM/main/packages/package_manifest.json'
    response = request.urlopen(url)
    return json.loads(response.read())


def scrapePackageNames():
    url = 'https://github.com/HeydoubleU/BPM/tree/main/packages'
    html = str(request.urlopen(url).read())
    front = 'class="js-navigation-open Link--primary" title="'
    x = len(front)
    matches = re.findall(f'{front}.+?"', html)

    return [match[x:-1] for match in matches]


def getPackageInfo(package):
    url = f'https://raw.githubusercontent.com/HeydoubleU/BPM/main/packages/{package}/package_info.json'
    response = request.urlopen(url)
    info = json.loads(response.read())

    # convert dependencies to list of tuples
    for version in info['versions'].values():
        version['dependencies'] = [tuple(x) for x in version['dependencies']]

    return info


def getPackageDesc(package):
    url = f'https://raw.githubusercontent.com/HeydoubleU/BPM/main/packages/{package}/package_desc.json'
    response = request.urlopen(url)
    return json.loads(response.read())


def installPackage(package, version='', info=None):

    if not info:
        try:
            info = getPackageInfo(package)
        except HTTPError:
            cmn.updateStatus(f'ERROR: {package} does not exist!')
            return

    if not version:
        version = info['current_version']

    url = f'https://github.com/HeydoubleU/BPM/blob/main/packages/{package}/{version}.zip?raw=true'
    dst = f'{cmn.BPM_LIB_PATH}/packages/{package}_{version}'

    cmn.updateStatus(f'Downloading: {package} {version}')
    cmn.STATUS_INDENT = 10
    try:
        response = request.urlopen(url)
    except HTTPError:
        cmn.STATUS_INDENT = 0
        cmn.updateStatus(f'ERROR: {package} {version} does not exist')
        return

    removePackageMajorVersion(package, minorToMajor(version))

    cmn.updateStatus('Extracting...')
    zipfile = ZipFile(BytesIO(response.read()))
    zipfile.extractall(path=dst)
    cmn.updateStatus('Done')
    cmn.STATUS_INDENT = 0


def updateLocalPackageSet():
    global LOCAL_PACKAGE_PATHS
    global LOCAL_PACKAGE_SET
    LOCAL_PACKAGE_PATHS.clear()
    LOCAL_PACKAGE_SET.clear()

    path = cmn.BPM_LIB_PATH + '/packages'
    dir_items = [x for x in os.listdir(path) if os.path.isdir(os.path.join(path, x))]

    for folder in dir_items:
        split = tuple(folder.split('_', 1))
        if len(split) != 2:
            continue
        LOCAL_PACKAGE_SET.add(split)
        LOCAL_PACKAGE_PATHS[split] = f'{path}/{folder}'


def removePackageMajorVersion(package_to_remove, major_version=''):
    if major_version:
        for package, version in LOCAL_PACKAGE_SET:
            if package == package_to_remove:
                if minorToMajor(version) == major_version:
                    QFile(LOCAL_PACKAGE_PATHS[(package, version)]).moveToTrash()
                    cmn.updateStatus(f'Removing: {package} {version}')

    else:
        for package, version in LOCAL_PACKAGE_SET:
            if package == package_to_remove:
                QFile(LOCAL_PACKAGE_PATHS[(package, version)]).moveToTrash()
                cmn.updateStatus(f'Removing: {package} {version}')


def installPackageSet(package_set: set, info_dict: dict = None):
    updateLocalPackageSet()

    cmn.updateStatus('-- Installing Package Set --\n')

    if info_dict:
        for x, (package, version) in enumerate(package_set):
            cmn.updateStatus(f'({x+1}/{len(package_set)}) ', post_line=False)
            installPackage(package, version, info_dict[package])
    else:
        for x, (package, version) in enumerate(package_set):
            cmn.updateStatus(f'({x+1}/{len(package_set)}) ', post_line=False)
            installPackage(package, version)

    cmn.updateStatus('\n-- Installation Finished --')


def currentVersionWithinMajor(major, info):
    for version in info['versions']:
        if version.startswith(major):
            if info['versions'][version]['current']:
                return version


def extendPackageSetToDependencies(package_set: set):
    cmn.updateStatus('Getting top level dependencies ', post_line=False)
    
    info_dict = {}
    unchecked_deps = set()

    # get top level package version if unspecified, then add dependencies to be checked
    buffer = set(package_set)
    package_set.clear()
    for package, version in buffer:
        cmn.updateStatus('.', post_line=False)
        info = getPackageInfo(package)
        info_dict[package] = info
        
        if not version:
            version = info['current_version']

        package_set.add((package, version))

        # dependency structure: (package-name, <major version>)
        unchecked_deps = unchecked_deps.union(set(info['versions'][version]['dependencies']))

    cmn.updateStatus('Getting sub dependencies ', pre_line=True, post_line=False)
    dep_count_grew = True
    while dep_count_grew:
        cmn.updateStatus('.', post_line=False)
        dep_count = len(package_set)

        buffer = set(unchecked_deps)
        unchecked_deps.clear()
        for dep in buffer:
            cmn.updateStatus('.', post_line=False)

            # get dependency package info if not in dict
            # cannot skip altogether because 2nd occurrence may be a different major version
            if dep[0] not in info_dict:
                info_dict[dep[0]] = getPackageInfo(dep[0])

            # swap major version for current minor version
            version = currentVersionWithinMajor(dep[1], info_dict[dep[0]])
            versioned_dep = (dep[0], version)

            # only add dep to check if the exact package/version has not already be added
            if versioned_dep not in package_set:
                package_set.add(versioned_dep)
                unchecked_deps = unchecked_deps.union(set(info_dict[dep[0]]['versions'][version]['dependencies']))

        dep_count_grew = len(package_set) > dep_count

    return package_set, info_dict


# Removes package from set if the exact version is already installed
def filterPackageSet(package_set: set):
    updateLocalPackageSet()
    for package in set(package_set):
        if package in LOCAL_PACKAGE_SET:
            cmn.updateStatus(f'{package[0]} {package[1]} (already installed)')
            package_set.remove(package)


def minorToMajor(version: str):
    return version.split('.', 1)[0]


def checkForUpdates():
    updateLocalPackageSet()
    minorUpdates = set()
    majorUpdates = set()
    for package, version in LOCAL_PACKAGE_SET:
        try:
            info = getPackageInfo(package)
        except HTTPError:
            print(f'Cannot get info for {package}, it may have been removed by the owner')
            continue

        current_minor = currentVersionWithinMajor(minorToMajor(version), info)

        if current_minor != version:
            minorUpdates.add((package, current_minor, version))

        if current_minor != info['current_version']:
            majorUpdates.add((package, info['current_version'], version))

    return minorUpdates, majorUpdates


LOCAL_PACKAGE_PATHS = {}
LOCAL_PACKAGE_SET = set()
updateLocalPackageSet()
