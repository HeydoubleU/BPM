from importlib import reload

import BPM
import BPM.common
import BPM.threads
import BPM.IO
import BPM.UI

reload(BPM)
reload(BPM.common)
reload(BPM.threads)
reload(BPM.IO)
reload(BPM.UI)

BPM.start()
print('beep boop')