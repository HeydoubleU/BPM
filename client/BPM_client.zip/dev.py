from importlib import reload

import BPM
import BPM.common
import BPM.threads
import BPM.IO
import BPM.UI

reload(BPM)
reload(BPM.common)
reload(BPM.threads)
reload(BPM.IO)
reload(BPM.UI)

BPM.start()
# BPM.UI.PublishPackageWindow()
print('beep boop')

# creation pacakge wizard
# self updater