from urllib import request
from http.client import HTTPResponse
from time import sleep

from PySide2.QtCore import QThread, Signal
from PySide2.QtWidgets import QLineEdit

from . import IO, common as cmn


class Downloader(QThread):
    response = Signal(HTTPResponse)
    url = 'https://raw.githubusercontent.com/HeydoubleU/BPM/main/packages/package_manifest.json'

    def run(self):
        self.response.emit(request.urlopen(self.url))
        super(self.__class__, self).run()


class PackageSearcher(QThread):
    client_update = Signal(str, str, str)
    package_update = Signal()
    matches_found = Signal(list)
    last_text = ''
    tick_interval = 0.5
    searching = True
    lineEdit: QLineEdit

    def run(self):
        # Check for updates
        if not cmn.hasBeenCalled('run', False):
            from . import __version__
            client_info = IO.getClientInfo()
            if client_info['version'] != __version__:
                cmn.ONCE_FUNCS.append('run')
                self.client_update.emit(__version__, client_info['version'], client_info['reload_script'])

        if IO.checkForUpdates(True):
            self.package_update.emit()

        # Search tick
        package_manifest = IO.scrapePackageNames()
        while self.searching:
            text = self.lineEdit.text().lower().replace(' ', '-')

            if text != self.last_text:
                self.last_text = text
                matches = []
                if text:
                    for key in package_manifest:
                        if text in key.lower():
                            matches.append(key)

                self.matches_found.emit(matches)

            sleep(self.tick_interval)

        super(self.__class__, self).run()  # probably dumb but for just in case I'm missing something
