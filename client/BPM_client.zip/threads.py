from urllib import request
from http.client import HTTPResponse
from time import sleep

from PySide2.QtCore import QThread, Signal
from PySide2.QtWidgets import QLineEdit

from . import IO


class Downloader(QThread):
    response = Signal(HTTPResponse)
    url = 'https://raw.githubusercontent.com/HeydoubleU/BPM/main/packages/package_manifest.json'

    def run(self):
        self.response.emit(request.urlopen(self.url))
        super(self.__class__, self).run()


class PackageSearcher(QThread):
    matches_found = Signal(list)
    last_text = ''
    tick_interval = 0.5
    searching = True
    lineEdit: QLineEdit

    def run(self):
        package_manifest = IO.scrapePackageNames()
        while self.searching:
            text = self.lineEdit.text().lower().replace(' ', '-')

            if text != self.last_text:
                self.last_text = text
                matches = []
                if text:
                    for key in package_manifest:
                        if text in key.lower():
                            matches.append(key)

                self.matches_found.emit(matches)

            sleep(self.tick_interval)

        super(self.__class__, self).run()